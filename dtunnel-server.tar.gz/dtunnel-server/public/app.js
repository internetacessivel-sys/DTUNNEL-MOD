/* Painel DTunnel - edicao dos JSONs servidos via gRPC */
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));

  let current = 'configs';
  let rows = [];
  let dirty = false;
  let schema = null;      // schema de edicao das conexoes
  let categories = [];    // categorias existentes (do /api/categories)
  const SCHEMA_FIELDS = new Map();   // chave -> definicao do campo
  let editIdx = null;     // indice da conexao em edicao (-1 = nova)

  const TITLES = {
    configs: 'Conexões',
    categories: 'Categorias',
    cdns: 'Endpoints',
    app_configs: 'App Config',
    texts: 'Textos',
  };

  const PRIMARY = {
    configs: 'name',
    categories: 'name',
    cdns: 'value',
    app_configs: 'name',
    texts: 'label',
  };

  const SUBTITLE = {
    configs: 'id',
    categories: 'id',
    cdns: 'name',
    app_configs: 'type',
    texts: 'text',
  };

  function toast(msg, kind = '') {
    const t = $('#toast');
    t.textContent = msg;
    t.className = `toast show ${kind}`;
    clearTimeout(t._t);
    t._t = setTimeout(() => (t.className = 'toast'), 2600);
  }

  async function api(url, opts) {
    const res = await fetch(url, opts);
    if (!res.ok) {
      let msg = res.statusText;
      try { msg = (await res.json()).error || msg; } catch (_) {}
      throw new Error(msg);
    }
    return res.json();
  }

  async function loadStatus() {
    try {
      const s = await api('/api/status');
      const g = s.grpc ? ' <b class="ok">gRPC ativo</b>' : ' <b class="err">gRPC inativo</b>';
      $('#status').innerHTML = `${s.dataDir}${g}`;
    } catch (e) {
      $('#status').innerHTML = `<b class="err">${e.message}</b>`;
    }
  }

  async function load() {
    if (current === 'logs') return loadLogs();
    if (current === 'configs') {
      try {
        const r = await api('/api/categories');
        categories = r.data || [];
      } catch (_) {}
    }
    const { data } = await api(`/api/${current}`);
    rows = data;
    dirty = false;
    render();
  }

  async function loadLogs() {
    const { lines } = await api('/api/logs?n=300');
    $('#logs').textContent = (lines || []).join('\n') || '(sem logs)';
    $('#logs').scrollTop = $('#logs').scrollHeight;
    $('#editor').classList.add('hidden');
    $('#logs').classList.remove('hidden');
    $('#count').textContent = `${(lines || []).length} linhas`;
  }

  function filtered() {
    const q = $('#search').value.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r) => JSON.stringify(r).toLowerCase().includes(q));
  }

  function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
    );
  }

  function fmt(v) {
    if (Array.isArray(v)) return v.join(', ');
    if (v === null || v === undefined) return '';
    if (typeof v === 'object') return JSON.stringify(v);
    return String(v);
  }

  // ---------------------------------------------------------------- conexões

  /** Rotulo do modo de conexão (bonito). */
  function modeLabel(mode) {
    if (schema && schema.modes[mode]) return schema.modes[mode].label;
    return mode || '—';
  }

  /** Resumo curto de uma conexão, para a lista. */
  function configSummary(c) {
    const parts = [];
    if (c.servers) parts.push(c.servers + (c.port ? ':' + c.port : ''));
    if (c.proxy && c.proxy.length) parts.push('proxy ' + (Array.isArray(c.proxy) ? c.proxy[0] : c.proxy));
    if (c.dns && c.dns.length) parts.push('dns ' + c.dns[0]);
    if (c.tls) parts.push(c.tls);
    if (c.mtu) parts.push('mtu ' + c.mtu);
    return parts.join(' • ');
  }

  function renderConfigs() {
    const list = filtered();
    $('#count').textContent = `${list.length} de ${rows.length} conexões${dirty ? ' • não salvo' : ''}`;
    if (!rows.length) {
      $('#editor').innerHTML = '<div class="empty">Nenhuma conexão. Use "+ Novo" para criar.</div>';
      return;
    }
    const html = list
      .map((row) => {
        const idx = rows.indexOf(row);
        const mode = row.mode || row.type || '';
        return `
      <div class="row cfg" data-idx="${idx}">
        <div class="row-head">
          <span class="row-title">${esc(row.name || '(sem nome)')}</span>
          <span class="row-meta">
            <span class="badge mode">${esc(modeLabel(mode))}</span>
            ${row.category ? `<span class="badge">${esc(row.category)}</span>` : ''}
            <span class="badge">${esc(configSummary(row))}</span>
          </span>
          <button class="btn ghost" data-edit="${idx}">Editar</button>
          <button class="btn ghost danger" data-del="${idx}">Excluir</button>
        </div>
      </div>`;
      })
      .join('');
    $('#editor').innerHTML = html;

    $$('[data-edit]').forEach((b) =>
      b.addEventListener('click', (ev) => {
        ev.stopPropagation();
        openEditor(+b.dataset.edit);
      })
    );
    $$('[data-del]').forEach((b) =>
      b.addEventListener('click', (ev) => {
        ev.stopPropagation();
        const i = +b.dataset.del;
        if (!confirm(`Excluir "${rows[i].name || ''}"?`)) return;
        rows.splice(i, 1);
        dirty = true;
        render();
      })
    );
  }

  /** Formulário de edição (modal) com os campos do modo escolhido. */
  function openEditor(idx) {
    editIdx = idx;
    const isNew = idx < 0;
    const c = isNew ? { mode: schema ? schema.defaultMode : 'SSH_PROXY' } : rows[idx];
    const mode = c.mode || c.type || (schema ? schema.defaultMode : 'SSH_PROXY');
    const groups = schema ? schema.modes[mode].groups : [['Campos', []]];

    const body = groups
      .map(([label, fields]) => `
      <fieldset>
        <legend>${esc(label)}</legend>
        <div class="grid">
          ${fields.map((f) => fieldHtml(c, f)).join('')}
        </div>
      </fieldset>`)
      .join('');

    const modes = Object.entries(schema ? schema.modes : {})
      .map(([k, m]) => `<option value="${esc(k)}" ${k === mode ? 'selected' : ''}>${esc(m.label)}</option>`)
      .join('');

    $('#modal').innerHTML = `
    <div class="modal-box">
      <div class="modal-head">
        <h2>${isNew ? 'Nova conexão' : 'Editar conexão'}</h2>
        <select id="fMode">${modes}</select>
        <button class="btn ghost" id="mClose">✕</button>
      </div>
      <div class="modal-hint">${esc(schema && schema.modes[mode] ? schema.modes[mode].hint : '')}</div>
      <div class="modal-body">${body}</div>
      <div class="modal-foot">
        <button class="btn ghost" id="mCancel">Cancelar</button>
        <button class="btn primary" id="mSave">Salvar no servidor</button>
      </div>
    </div>`;
    $('#modal').classList.remove('hidden');

    $('#mClose').addEventListener('click', closeEditor);
    $('#mCancel').addEventListener('click', closeEditor);
    $('#mSave').addEventListener('click', async () => {
      // 1) aplica o formulario na conexao (senao o PUT manda o array antigo)
      applyEditor();
      // 2) grava no servidor
      const ok = await save();
      if (ok) closeEditor();
    });
    // categoria: mostra o campo de nova categoria
    $$('#modal select[data-cat]').forEach((sel) => {
      const novo = sel.parentElement.querySelector('input[type=text]');
      const toggle = () => {
        if (novo) novo.classList.toggle('hidden', sel.value !== '__new__');
      };
      sel.addEventListener('change', toggle);
      toggle();
    });
    // trocar de modo -> re-abre o formulario com os campos daquele modo
    $('#fMode').addEventListener('change', (ev) => {
      const m = ev.target.value;
      const cur = isNew ? { mode: m } : Object.assign({}, rows[idx], { mode: m, type: m });
      if (!isNew) rows[idx] = cur;
      openEditor(idx);
    });
  }

  /** Le um valor por caminho ("server.host") no objeto. */
  function getPath(obj, path) {
    if (!path || path.indexOf('.') < 0) return obj ? obj[path] : undefined;
    const partes = path.split('.');
    let cur = obj;
    for (const p of partes) {
      if (cur === null || cur === undefined) return undefined;
      cur = cur[p];
    }
    return cur;
  }

  /** Escreve um valor por caminho ("server.host"), criando o que faltar. */
  function setPath(obj, path, valor) {
    if (!path || path.indexOf('.') < 0) { obj[path] = valor; return; }
    const partes = path.split('.');
    let cur = obj;
    for (let i = 0; i < partes.length - 1; i++) {
      const p = partes[i];
      if (cur[p] === null || typeof cur[p] !== 'object') cur[p] = {};
      cur = cur[p];
    }
    cur[partes[partes.length - 1]] = valor;
  }

  /** Valor do campo: usa a chave principal ou a alternativa (bot_url, hosts...). */
  function fieldValue(c, f) {
    const vazio = (v) => v === undefined || v === null || v === '' || (Array.isArray(v) && !v.length);
    // 1) caminhos do schema (aninhado do painel oficial + plano)
    for (const p of (f.paths || (f.path ? [f.path] : []))) {
      const v = getPath(c, p);
      if (!vazio(v)) return v;
    }
    // 2) chaves alternativas (bot_url, hosts...)
    for (const k of (f.keys || [f.k])) {
      const v = c[k];
      if (!vazio(v)) return v;
    }
    return '';
  }

  function fieldHtml(c, f) {
    const v = fieldValue(c, f);
    const id = `f_${f.k}`;
    // campo "auto": infere do valor atual (checkbox p/ bool, number p/ numero)
    let ft = f.t;
    if (ft === 'auto') {
      ft = typeof v === 'boolean' ? 'bool'
         : typeof v === 'number' ? 'number'
         : Array.isArray(v) ? 'dns' : 'text';
    }
    if (ft === 'bool') {
      return `<label class="fld chk"><input type="checkbox" id="${id}" data-k="${f.k}" ${v ? 'checked' : ''}><span>${esc(f.l)}</span></label>`;
    }
    if (ft === 'category') {
      // a categoria atual: pelo id do objeto (formato do painel) ou pelo category_id
      const catObj = c && typeof c.category === 'object' ? c.category : null;
      const atual = String((catObj && (catObj.id || catObj.name)) || (c && c.category_id) || '');
      const nomeAtual = catObj ? (catObj.name || '') : '';
      const opts = categories
        .map((cat) => `<option value="${esc(cat.id)}" ${String(cat.id) === String(atual) ? 'selected' : ''}>${esc(cat.name || ('#' + cat.id))}</option>`)
        .join('');
      return `<label class="fld wide">
        <span>${esc(f.l)}</span>
        <select id="${id}" data-k="${f.k}" data-cat="1">
          <option value="">${esc(nomeAtual || '— selecione —')}</option>
          ${opts}
          <option value="__new__">＋ nova categoria…</option>
        </select>
        <input type="text" id="${id}_new" class="hidden" placeholder="nome da nova categoria">
      </label>`;
    }
    if (ft === 'select') {
      const opts = (f.opts || []).map((o) => `<option ${String(v) === String(o) ? 'selected' : ''}>${esc(o)}</option>`).join('');
      return `<label class="fld"><span>${esc(f.l)}</span><select id="${id}" data-k="${f.k}">${opts}</select></label>`;
    }
    if (ft === 'textarea') {
      return `<label class="fld wide"><span>${esc(f.l)}</span><textarea id="${id}" data-k="${f.k}" rows="3" placeholder="${esc(f.h || '')}">${esc(v ?? '')}</textarea></label>`;
    }
    if (ft === 'dns') {
      const d = Array.isArray(v) ? v.join('\n') : (v || '');
      return `<label class="fld wide"><span>${esc(f.l)}</span><textarea id="${id}" data-k="${f.k}" data-dns="1" rows="2" placeholder="${esc(f.h || '')}">${esc(d)}</textarea></label>`;
    }
    return `<label class="fld"><span>${esc(f.l)}</span><input type="${ft === 'number' ? 'number' : 'text'}" id="${id}" data-k="${f.k}" value="${esc(v ?? '')}" placeholder="${esc(f.h || '')}"></label>`;
  }

  function closeEditor() {
    $('#modal').classList.add('hidden');
    $('#modal').innerHTML = '';
    editIdx = null;
  }

  /** Aplica o que esta no formulario no objeto da conexao (sem fechar). */
  function applyEditor() {
    let categoriaSel = null;
    const c = editIdx < 0 ? {} : Object.assign({}, rows[editIdx]);
    const mode = $('#fMode').value;
    c.mode = mode;
    c.type = mode;
    $$('#modal [data-k]').forEach((el) => {
      const k = el.dataset.k;
      const f = SCHEMA_FIELDS.get(k) || { k };
      let val;
      if (el.type === 'checkbox') val = el.checked;
      else if (el.dataset.dns) val = el.value.split('\n').map((s) => s.trim()).filter(Boolean);
      else if (el.type === 'number') val = el.value === '' ? 0 : Number(el.value);
      else if (el.dataset.cat) {
        // categoria: selecionada da lista ou nova (digitada)
        const inp = el.parentElement.querySelector('input[type=text]');
        const nova = inp && !inp.classList.contains('hidden') ? inp.value.trim() : '';
        if (el.value === '__new__') {
          if (!nova) { toast('Digite o nome da nova categoria', 'err'); return; }
          val = nova;                       // nome texto (criada no save)
        } else if (el.value === '') {
          val = '';                          // sem categoria
        } else {
          const cat = categories.find((x) => String(x.id) === String(el.value) || x.name === el.value);
          val = cat ? cat.name : el.value;
        }
        categoriaSel = { id: el.value, nova, nome: val };
      }
      else val = el.value;
      // grava no caminho aninhado (formato da API oficial) e apaga as
      // alternativas, para nao ficar com dois valores diferentes
      const paths = f.paths || (f.path ? [f.path] : []);
      if (paths.length) {
        // grava onde o item ja tem o campo (mantem o formato do arquivo);
        // se nao existe, grava no caminho principal
        let destino = paths[0];
        for (const p of paths) {
          if (getPath(c, p) !== undefined) { destino = p; break; }
        }
        // limpa as alternativas ANTES de gravar (senao apaga o que gravamos)
        for (const alt of (f.keys || [f.k])) {
          if (alt !== k && !destino.startsWith(alt + '.')) delete c[alt];
        }
        if (destino !== k && !paths.some((p) => p.startsWith(k + '.'))) delete c[k];
        setPath(c, destino, val);
      } else {
        for (const alt of (f.keys || [f.k])) {
          if (alt !== k) delete c[alt];
        }
        c[k] = val;
      }
    });
    // categoria: id + nome no formato aninhado do painel oficial
    // (aplicado por ultimo: nenhum outro campo pode sobrescrever o id)
    if (categoriaSel && categoriaSel.id) {
      const cat = c.category && typeof c.category === 'object' ? Object.assign({}, c.category) : {};
      let ex = null;
      if (categoriaSel.id === '__new__') {
        cat.id = Date.now() % 1000000;
        cat.name = categoriaSel.nome;
      } else {
        cat.id = Number(categoriaSel.id);
        ex = categories.find((x) => String(x.id) === String(categoriaSel.id));
        cat.name = ex ? ex.name : categoriaSel.nome;
      }
      cat.color = cat.color || (ex && ex.color) || '#2196F3';
      cat.sorter = cat.sorter || (ex && ex.sorter) || 1;
      c.category = cat;
      c.category_id = cat.id;
    }
    if (categoriaSel && categoriaSel.id) {
      const cat = c.category && typeof c.category === 'object' ? Object.assign({}, c.category) : {};
      let ex = null;
      if (categoriaSel.id === '__new__') {
        cat.id = Date.now() % 1000000;
        cat.name = categoriaSel.nome;
      } else {
        cat.id = Number(categoriaSel.id);
        ex = categories.find((x) => String(x.id) === String(categoriaSel.id) || x.name === categoriaSel.id);
        cat.name = ex ? ex.name : categoriaSel.nome;
      }
      cat.color = cat.color || (ex && ex.color) || '#2196F3';
      cat.sorter = cat.sorter || (ex && ex.sorter) || 1;
      c.category = cat;
      c.category_id = cat.id;      // o id vem da categoria escolhida
      delete c.category_name;
    }
    if (editIdx < 0) {
      c.id = Date.now() % 100000000;
      rows.push(c);
      editIdx = rows.length - 1;
    } else {
      rows[editIdx] = c;
    }
    dirty = true;
    render();
  }

  // ---------------------------------------------------------------- genérico

  function fieldsHtml(row, idx) {
    const keys = Object.keys(row).filter((k) => !['id', 'name', 'label', 'value'].includes(k));
    return `<div class="grid">${keys
      .map((k) => {
        const v = row[k];
        const isArr = Array.isArray(v);
        const isBool = typeof v === 'boolean';
        return `<label class="fld ${isArr || typeof v === 'object' ? 'wide' : ''}">
        <span>${esc(k)}</span>
        ${isBool
          ? `<input type="checkbox" data-key="${esc(k)}" ${v ? 'checked' : ''}>`
          : isArr || typeof v === 'object'
            ? `<textarea data-key="${esc(k)}" rows="2">${esc(fmt(v))}</textarea>`
            : `<input data-key="${esc(k)}" value="${esc(v ?? '')}">`}
      </label>`;
      })
      .join('')}</div>`;
  }

  function render() {
    $('#logs').classList.add('hidden');
    $('#editor').classList.remove('hidden');
    if (current === 'configs') return renderConfigs();

    const list = filtered();
    $('#count').textContent = `${list.length} de ${rows.length} itens${dirty ? ' • não salvo' : ''}`;

    if (!rows.length) {
      $('#editor').innerHTML = '<div class="empty">Nenhum item. Use "+ Novo" para criar.</div>';
      return;
    }

    const html = list
      .map((row) => {
        const idx = rows.indexOf(row);
        const title = row[PRIMARY[current]] ?? row.name ?? row.label ?? `#${idx}`;
        const sub = row[SUBTITLE[current]];
        const extra = Object.keys(row)
          .filter((k) => k !== PRIMARY[current] && k !== SUBTITLE[current])
          .slice(0, 3)
          .map((k) => `<span class="badge">${esc(k)}: ${esc(fmt(row[k]))}</span>`)
          .join('');
        return `
      <div class="row" data-idx="${idx}">
        <div class="row-head">
          <span class="row-title">${esc(title)}</span>
          <span class="row-meta">${sub !== undefined ? `<span class="badge">${esc(sub)}</span>` : ''}${extra}</span>
          <button class="btn ghost danger" data-del="${idx}">Excluir</button>
        </div>
        <div class="row-body">${fieldsHtml(row, idx)}</div>
      </div>`;
      })
      .join('');
    $('#editor').innerHTML = html;

    $$('.row-head').forEach((h) =>
      h.addEventListener('click', (ev) => {
        if (ev.target.closest('[data-del]')) return;
        h.parentElement.classList.toggle('open');
      })
    );
    $$('[data-del]').forEach((b) =>
      b.addEventListener('click', (ev) => {
        ev.stopPropagation();
        const i = +b.dataset.del;
        if (!confirm(`Excluir "${rows[i][PRIMARY[current]] ?? ''}"?`)) return;
        rows.splice(i, 1);
        dirty = true;
        render();
      })
    );
    $$('.row-body .field input, .row-body .field textarea').forEach((el) =>
      el.addEventListener('input', () => {
        const idx = +el.closest('.row').dataset.idx;
        const key = el.dataset.key;
        const val = el.type === 'checkbox' ? el.checked : el.value;
        rows[idx][key] = el.type === 'number' ? Number(val) : val;
        dirty = true;
        $('#count').textContent = `${filtered().length} de ${rows.length} itens • não salvo`;
      })
    );
  }

  /** Baixa as conexoes em JSON (formato da API oficial ou o plano do app). */
  async function exportJson() {
    if (current !== 'configs') { toast('A exportacao e so da aba Conexões', 'err'); return; }
    try {
      const formato = confirm('OK = formato da API oficial do DTunnel (aninhado)\nCancelar = formato plano que o app usa') ? 'api' : 'app';
      const res = await fetch('/api/configs/export?formato=' + formato);
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `dtunnel-conexoes-${formato}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
      toast(`Exportado: ${data.length} conexoes (${formato})`, 'ok');
    } catch (e) {
      toast('Erro ao exportar: ' + e.message, 'err');
    }
  }

  /** Importa conexoes de um JSON (API oficial ou plano). */
  async function importJson(file) {
    try {
      const texto = await file.text();
      let payload = JSON.parse(texto);
      if (!Array.isArray(payload)) payload = payload.data || payload.configs || [];
      const r = await api('/api/configs/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: payload }),
      });
      toast(`Importado: ${r.count} conexoes (formato ${r.formato}). Salve para gravar.`, 'ok');
      await load();
      dirty = true;
    } catch (e) {
      toast('Erro ao importar: ' + e.message, 'err');
    }
  }

  async function save() {
    if (current === 'logs') return false;
    try {
      const r = await api(`/api/${current}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: rows }),
      });
      dirty = false;
      $('#count').textContent = `${rows.length} itens`;
      toast(`Salvo no servidor: ${r.count} itens. O app recebe na próxima atualização.`, 'ok');
      return true;
    } catch (e) {
      toast('Erro ao salvar: ' + e.message, 'err');
      return false;
    }
  }

  async function add() {
    if (current === 'configs') {
      openEditor(-1);
      return;
    }
    const t = current;
    const base = { name: 'novo', id: Date.now() % 100000000 };
    if (t === 'categories') { base.name = 'Nova categoria'; base.color = '#2196F3'; base.order = 0; }
    if (t === 'cdns') { base.name = 'novo'; base.value = 'exemplo.com'; base.type = 'CDN'; }
    if (t === 'app_configs') { base.name = 'novo'; base.type = 'STRING'; base.value = ''; }
    if (t === 'texts') { base.label = 'novo'; base.text = ''; }
    rows.push(base);
    dirty = true;
    render();
  }

  async function restore() {
    if (!confirm('Restaurar o backup (.bak) do arquivo atual?')) return;
    try {
      const r = await api(`/api/${current}/restore`, { method: 'POST' });
      toast(`Restaurado: ${r.count} itens`, 'ok');
      load();
    } catch (e) {
      toast('Erro: ' + e.message, 'err');
    }
  }

  // ---------------------------------------------------------------- boot

  async function boot() {
    $$('#tabs .tab').forEach((t) =>
      t.addEventListener('click', () => {
        $$('#tabs .tab').forEach((x) => x.classList.remove('active'));
        t.classList.add('active');
        current = t.dataset.file;
        $('#search').value = '';
        const isCfg = current === 'configs';
        $('#export').classList.toggle('hidden', !isCfg);
        $('#import').classList.toggle('hidden', !isCfg);
        load();
      })
    );
    $('#save').addEventListener('click', save);
    $('#export').addEventListener('click', exportJson);
    $('#import').addEventListener('click', () => $('#importFile').click());
    $('#importFile').addEventListener('change', (ev) => {
      const f = ev.target.files && ev.target.files[0];
      if (f) importJson(f);
      ev.target.value = '';
    });
    $('#add').addEventListener('click', add);
    $('#reload').addEventListener('click', () => load());
    $('#restore').addEventListener('click', restore);
    $('#search').addEventListener('input', render);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !$('#modal').classList.contains('hidden')) closeEditor();
      if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); save(); }
    });

    try {
      const r = await api('/api/categories');
      categories = r.data || [];
    } catch (_) {
      categories = [];
    }
    try {
      schema = await api('/api/config-schema');
      for (const m of Object.values(schema.modes)) {
        for (const [, fields] of m.groups) {
          for (const f of fields) SCHEMA_FIELDS.set(f.k, f);
        }
      }
    } catch (_) {
      schema = null;
    }
    // botoes de conexao (exportar/importar) so na aba Conexões
    const isCfg = current === 'configs';
    $('#export').classList.toggle('hidden', !isCfg);
    $('#import').classList.toggle('hidden', !isCfg);

    loadStatus();
    load();
    setInterval(loadStatus, 15000);
  }

  boot();
})();
