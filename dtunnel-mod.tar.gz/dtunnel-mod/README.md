# DTunnel — Pacote do Mod

Contém o APK modificado do DTunnel e todas as ferramentas para **refazer o mod**
(para outro servidor, outra chave, etc.).

## Conteúdo

```
apk/
  DTunnel_5.0.0.apk        APK original (para refazer o mod do zero)
  dt_patched_signed.apk     APK já modificado e assinado (pronto para instalar)
patch/
  patch_mod.py              aplica os patches de smali (idempotente)
  build_apk.py              constrói + alinha + assina o APK
  gen_keys.sh               gera CA, certificado TLS e chave de assinatura
  dt2.jks                   keystore de assinatura do APK (alias: dt / dtpass)
keys/
  server_reply.key          chave privada de assinatura dos replies (ECDSA P-256)
  server_reply_key.json     chave pública (vai para o wz.h do APK)
make_mod.sh                 fluxo completo em um comando
```

## Uso rápido — só instalar

```bash
adb install -r apk/dt_patched_signed.apk
```

O APK já está apontando para `SEU_IP:443`.

## Refazer o mod para outro servidor

```bash
./make_mod.sh MEU_IP 443
```

Ou passo a passo:

```bash
# 1. decode
java -jar ~/tools/apktool/apktool.jar d apk/DTunnel_5.0.0.apk -o build/dt -f

# 2. patches + host/porta + chave publica
python3 patch/patch_mod.py --project build/dt \
    --host MEU_IP --port 443 \
    --reply-pub-file keys/server_reply_key.json

# 3. build + assinar
python3 patch/build_apk.py --project build/dt --out dist/dt_patched_signed.apk \
    --keystore patch/dt2.jks --ks-pass dtpass --ks-alias dt

# 4. instalar
adb install -r dist/dt_patched_signed.apk
```

## Nota sobre os labels do smali

O apktool reordena os labels `:array_N` ao reescrever o arquivo, então o
`patch_mod.py` **não** depende dos nomes: ele localiza cada array pelo campo
que ele alimenta (`wz.f` = host, `wz.g` = porta, `wz.h` = chave pública) e
usa o label dedicado `:array_porta` para a porta. Assim o script funciona
com qualquer versão do APK original.

## Requisitos

- **Java** (JDK 17+) — para o apktool
- **apktool** — https://apktool.org (`~/tools/apktool/apktool.jar` ou no PATH)
- **Android SDK build-tools** — `zipalign` e `apksigner`
  (define `ANDROID_SDK_ROOT` se não estiver em `~/Android/Sdk`)
- **adb** — para instalar no celular
- **Python 3.8+**

## O que o mod faz

| Patch | Efeito |
|---|---|
| `c.smali` | `c.r()` deixa de lançar `IllegalStateException` → app não fecha com **"Remote channel unavailable"** no boot |
| `c41.smali` | ignora a verificação de **assinatura do reply** gRPC |
| `xt.smali` | ignora a verificação de **assinatura do config bundle** |
| `qx1.smali` | `HostnameVerifier` sempre retorna `true` |
| `p6.smali` | injeta um `X509TrustManager` que **aceita qualquer certificado TLS** (bypass de SSL) |
| `wz.smali` | grava o **host/porta** do servidor de update e a **chave pública** de assinatura do reply (`wz.h`) |

## ⚠️ Ponto crítico: chave de assinatura do reply

O app valida a assinatura de cada resposta do servidor usando a chave pública
embutida no APK (`wz.h`). O servidor precisa assinar com a **chave privada
correspondente**.

- `keys/server_reply.key` (neste pacote) **tem de ser a mesma** que está no
  servidor (`dtunnel-server/keys/server_reply.key`).
- Se você gerar uma chave nova com `patch/gen_keys.sh`, precisa:
  1. usar a chave nova no servidor, **e**
  2. refazer o APK passando o novo `server_reply_key.json` ao `patch_mod.py`
     (é para isso que o `--reply-pub-file` existe).

Se os dois lados divergirem, o app **descarta a resposta** e a lista de
conexões fica vazia (sem erro visível).

## Certificado TLS

O app também valida o certificado TLS do servidor, mas isso é burlado pelo
patch do `p6.smali` (trust manager que aceita tudo). Ainda assim, o
certificado é gerado e distribuído normalmente para funcionar com outros
clientes (e para o `openssl s_client`).

O `dtca.pem` (a CA) precisa estar embutido no APK como `res/raw/dtca.pem` para o
`network_security_config.xml` — o mod já vem com isso configurado.

## Keystore

`patch/dt2.jks` (alias `dt`, senha `dtpass`) é a keystore usada para assinar.
O Android **não** aceita instalar um APK assinado com uma chave diferente da
original — por isso o mod precisa assinar com esta keystore. Se o usuário já
tiver o app original instalado, será preciso desinstalar antes:

```bash
adb uninstall com.dtunnel
adb install -r apk/dt_patched_signed.apk
```
